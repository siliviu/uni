f = @(x)sin(x);
a = 0;
b = pi;

disp("real " + 2);
disp("addquad2 " + adquad2(f,a,b));