function sol=cossmall(x)
    order = 6;
    syms X;
    f = cos(X);
    %f = taylor(f, 'order', 2*order+1);
    f = pade_approx(f,order,order,X);
    sol = double(subs(f,X,x));
end