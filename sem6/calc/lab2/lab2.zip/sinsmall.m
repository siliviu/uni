function sol=sinsmall(x)
    order = 5;
    syms X;
    f = sin(X);
    %f = taylor(f, 'order', 2*order+1);
    f = pade_approx(f,order,order,X);
    sol = double(subs(f,X,x));
end