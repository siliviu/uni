%roots1 = [1 : 20]; 
%polynom1 = poly(roots1);
%poly_do(polynom1, roots1);

polynom2 = 2.^-(1 : 20);
poly_do(polynom2);
