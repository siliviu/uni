function [A, b] = generate_system_cholesky(n)
    R=rand(n,n);
    A = R*R'; 
    x = ones(n, 1);
    b = A * x;
end
