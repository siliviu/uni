% test 2
f = @(x) sin(x);
graph_hermite(f, [0, pi/4, pi/2], 0, pi);

% test 3
graph_cubic(2, 3, 16, 81, 32, 324);